package com.example.entity;

public enum ReportStatus {
    IN_PROCESS,
    PENDING,
    ON_HOLD,
    COMPLETED
}
