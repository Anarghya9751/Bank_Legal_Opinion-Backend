package com.example.entity;

public enum ReportType {
	 MONTHLY,
	    QUARTERLY,
	    ANNUAL
}
